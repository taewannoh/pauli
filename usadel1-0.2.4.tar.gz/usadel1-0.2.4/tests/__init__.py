"""
Tests for usadel1
"""

__revision__ = "$Id: __init__.py 3184 2006-10-02 07:05:45Z pauli $"

