.. index:: downloading

Download
========

.. note::

   This software can be freely used and modified for non-commercial purposes.
   If you use this software in academic publications, we recommend
   that you cite it appropriately. We also appreciate if you let us know
   of such use. See :ref:`license` for more.

You can download the source code here:

===================  ==========================================================
Source code          `usadel1-0.2.3.2.tar.gz`_
Development version  http://bitbucket.org/pv/usadel1/
===================  ==========================================================

.. _usadel1-0.2.3.2.tar.gz: _static/usadel1-0.2.3.2.tar.gz


